#!/bin/bash
sudo echo 'Hello World!' > /home/azadmin/hello.txt